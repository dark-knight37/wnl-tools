/**
 */
package WNLML;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Reservoir</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see WNLML.WNLMLPackage#getReservoir()
 * @model annotation="gmf.node label='name' label.icon='false' label.placement='external' figure='figures.ReservoirFigure'"
 * @generated
 */
public interface Reservoir extends WNNode {
} // Reservoir
