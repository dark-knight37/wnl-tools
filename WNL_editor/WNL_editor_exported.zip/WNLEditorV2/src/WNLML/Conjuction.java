/**
 */
package WNLML;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Conjuction</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see WNLML.WNLMLPackage#getConjuction()
 * @model annotation="gmf.node label='name' label.icon='false' label.placement='external' figure='ellipse' color='0,0,0' border.color='0,0,0' size='30,30'"
 * @generated
 */
public interface Conjuction extends WNNode {
} // Conjuction
