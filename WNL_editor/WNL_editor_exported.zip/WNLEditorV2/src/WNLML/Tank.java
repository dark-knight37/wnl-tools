/**
 */
package WNLML;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Tank</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see WNLML.WNLMLPackage#getTank()
 * @model annotation="gmf.node label='name' label.icon='false' label.placement='external' figure='figures.TankFigure'"
 * @generated
 */
public interface Tank extends WNNode {
} // Tank
