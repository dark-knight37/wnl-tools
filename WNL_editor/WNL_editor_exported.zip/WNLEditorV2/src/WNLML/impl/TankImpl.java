/**
 */
package WNLML.impl;

import WNLML.Tank;
import WNLML.WNLMLPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Tank</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class TankImpl extends WNNodeImpl implements Tank {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TankImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WNLMLPackage.Literals.TANK;
	}

} //TankImpl
