/**
 */
package WNLML.impl;

import WNLML.Reservoir;
import WNLML.WNLMLPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Reservoir</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ReservoirImpl extends WNNodeImpl implements Reservoir {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ReservoirImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WNLMLPackage.Literals.RESERVOIR;
	}

} //ReservoirImpl
