package figures;

import org.eclipse.draw2d.ImageFigure;
import activator.PluginActivator;

/**
 * @generated
 */
public class WaterPumpFigure extends ImageFigure {

    public WaterPumpFigure() {
        super(PluginActivator.imageDescriptorFromPlugin(PluginActivator.ID, "images/pump.jpg").createImage(), 0);
    }

}