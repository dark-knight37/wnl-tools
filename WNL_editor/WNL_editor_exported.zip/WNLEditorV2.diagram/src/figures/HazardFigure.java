package figures;

import org.eclipse.draw2d.ImageFigure;
import activator.PluginActivator;

/**
 * @generated
 */
public class HazardFigure extends ImageFigure {

    public HazardFigure() {
        super(PluginActivator.imageDescriptorFromPlugin(PluginActivator.ID, "images/hazard.png").createImage(), 0);
    }

}