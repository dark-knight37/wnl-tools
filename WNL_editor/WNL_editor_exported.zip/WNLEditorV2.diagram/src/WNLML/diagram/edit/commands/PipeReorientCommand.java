/*
 * 
 */
package WNLML.diagram.edit.commands;

import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.runtime.common.core.command.CommandResult;
import org.eclipse.gmf.runtime.emf.type.core.commands.EditElementCommand;
import org.eclipse.gmf.runtime.emf.type.core.requests.ReorientRelationshipRequest;

import WNLML.Pipe;
import WNLML.WNNode;
import WNLML.WaterNetwork;
import WNLML.diagram.edit.policies.WNLMLBaseItemSemanticEditPolicy;

/**
 * @generated
 */
public class PipeReorientCommand extends EditElementCommand {

	/**
	* @generated
	*/
	private final int reorientDirection;

	/**
	* @generated
	*/
	private final EObject oldEnd;

	/**
	* @generated
	*/
	private final EObject newEnd;

	/**
	* @generated
	*/
	public PipeReorientCommand(ReorientRelationshipRequest request) {
		super(request.getLabel(), request.getRelationship(), request);
		reorientDirection = request.getDirection();
		oldEnd = request.getOldRelationshipEnd();
		newEnd = request.getNewRelationshipEnd();
	}

	/**
	* @generated
	*/
	public boolean canExecute() {
		if (false == getElementToEdit() instanceof Pipe) {
			return false;
		}
		if (reorientDirection == ReorientRelationshipRequest.REORIENT_SOURCE) {
			return canReorientSource();
		}
		if (reorientDirection == ReorientRelationshipRequest.REORIENT_TARGET) {
			return canReorientTarget();
		}
		return false;
	}

	/**
	* @generated
	*/
	protected boolean canReorientSource() {
		if (!(oldEnd instanceof WNNode && newEnd instanceof WNNode)) {
			return false;
		}
		WNNode target = getLink().getDestination();
		if (!(getLink().eContainer() instanceof WaterNetwork)) {
			return false;
		}
		WaterNetwork container = (WaterNetwork) getLink().eContainer();
		return WNLMLBaseItemSemanticEditPolicy.getLinkConstraints().canExistPipe_4001(container, getLink(),
				getNewSource(), target);
	}

	/**
	* @generated
	*/
	protected boolean canReorientTarget() {
		if (!(oldEnd instanceof WNNode && newEnd instanceof WNNode)) {
			return false;
		}
		WNNode source = getLink().getSource();
		if (!(getLink().eContainer() instanceof WaterNetwork)) {
			return false;
		}
		WaterNetwork container = (WaterNetwork) getLink().eContainer();
		return WNLMLBaseItemSemanticEditPolicy.getLinkConstraints().canExistPipe_4001(container, getLink(), source,
				getNewTarget());
	}

	/**
	* @generated
	*/
	protected CommandResult doExecuteWithResult(IProgressMonitor monitor, IAdaptable info) throws ExecutionException {
		if (!canExecute()) {
			throw new ExecutionException("Invalid arguments in reorient link command"); //$NON-NLS-1$
		}
		if (reorientDirection == ReorientRelationshipRequest.REORIENT_SOURCE) {
			return reorientSource();
		}
		if (reorientDirection == ReorientRelationshipRequest.REORIENT_TARGET) {
			return reorientTarget();
		}
		throw new IllegalStateException();
	}

	/**
	* @generated
	*/
	protected CommandResult reorientSource() throws ExecutionException {
		getLink().setSource(getNewSource());
		return CommandResult.newOKCommandResult(getLink());
	}

	/**
	* @generated
	*/
	protected CommandResult reorientTarget() throws ExecutionException {
		getLink().setDestination(getNewTarget());
		return CommandResult.newOKCommandResult(getLink());
	}

	/**
	* @generated
	*/
	protected Pipe getLink() {
		return (Pipe) getElementToEdit();
	}

	/**
	* @generated
	*/
	protected WNNode getOldSource() {
		return (WNNode) oldEnd;
	}

	/**
	* @generated
	*/
	protected WNNode getNewSource() {
		return (WNNode) newEnd;
	}

	/**
	* @generated
	*/
	protected WNNode getOldTarget() {
		return (WNNode) oldEnd;
	}

	/**
	* @generated
	*/
	protected WNNode getNewTarget() {
		return (WNNode) newEnd;
	}
}
