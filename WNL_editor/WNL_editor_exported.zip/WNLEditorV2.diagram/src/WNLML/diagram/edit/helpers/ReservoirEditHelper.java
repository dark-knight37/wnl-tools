/*
 * 
 */
package WNLML.diagram.edit.helpers;

/**
 * @generated
 */
public class ReservoirEditHelper extends WNLMLBaseEditHelper {
}
