/*
 * 
 */
package WNLML.diagram.edit.helpers;

/**
 * @generated
 */
public class TankEditHelper extends WNLMLBaseEditHelper {
}
