/*
 * 
 */
package WNLML.diagram.edit.helpers;

/**
 * @generated
 */
public class WaterNetworkEditHelper extends WNLMLBaseEditHelper {
}
