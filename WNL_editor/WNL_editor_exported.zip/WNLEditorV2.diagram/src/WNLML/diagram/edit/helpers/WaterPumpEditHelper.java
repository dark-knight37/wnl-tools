/*
 * 
 */
package WNLML.diagram.edit.helpers;

/**
 * @generated
 */
public class WaterPumpEditHelper extends WNLMLBaseEditHelper {
}
