/*
 * 
 */
package WNLML.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.DiagramsPreferencePage;

import WNLML.diagram.part.WNLMLDiagramEditorPlugin;

/**
 * @generated
 */
public class DiagramGeneralPreferencePage extends DiagramsPreferencePage {

	/**
	* @generated
	*/
	public DiagramGeneralPreferencePage() {
		setPreferenceStore(WNLMLDiagramEditorPlugin.getInstance().getPreferenceStore());
	}
}
