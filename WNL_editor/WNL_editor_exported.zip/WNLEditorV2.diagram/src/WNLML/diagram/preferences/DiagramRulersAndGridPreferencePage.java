/*
 * 
 */
package WNLML.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.RulerGridPreferencePage;

import WNLML.diagram.part.WNLMLDiagramEditorPlugin;

/**
 * @generated
 */
public class DiagramRulersAndGridPreferencePage extends RulerGridPreferencePage {

	/**
	* @generated
	*/
	public DiagramRulersAndGridPreferencePage() {
		setPreferenceStore(WNLMLDiagramEditorPlugin.getInstance().getPreferenceStore());
	}
}
