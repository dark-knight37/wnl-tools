/*
 * 
 */
package WNLML.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.ConnectionsPreferencePage;

import WNLML.diagram.part.WNLMLDiagramEditorPlugin;

/**
 * @generated
 */
public class DiagramConnectionsPreferencePage extends ConnectionsPreferencePage {

	/**
	* @generated
	*/
	public DiagramConnectionsPreferencePage() {
		setPreferenceStore(WNLMLDiagramEditorPlugin.getInstance().getPreferenceStore());
	}
}
