/*
 * 
 */
package WNLML.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.AppearancePreferencePage;

import WNLML.diagram.part.WNLMLDiagramEditorPlugin;

/**
 * @generated
 */
public class DiagramAppearancePreferencePage extends AppearancePreferencePage {

	/**
	* @generated
	*/
	public DiagramAppearancePreferencePage() {
		setPreferenceStore(WNLMLDiagramEditorPlugin.getInstance().getPreferenceStore());
	}
}
