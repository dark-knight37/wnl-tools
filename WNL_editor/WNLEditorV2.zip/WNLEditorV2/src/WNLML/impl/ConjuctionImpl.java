/**
 */
package WNLML.impl;

import WNLML.Conjuction;
import WNLML.WNLMLPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Conjuction</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ConjuctionImpl extends WNNodeImpl implements Conjuction {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ConjuctionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WNLMLPackage.Literals.CONJUCTION;
	}

} //ConjuctionImpl
