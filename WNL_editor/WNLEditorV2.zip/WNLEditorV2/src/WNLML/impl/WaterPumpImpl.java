/**
 */
package WNLML.impl;

import WNLML.WNLMLPackage;
import WNLML.WaterPump;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Water Pump</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class WaterPumpImpl extends WNNodeImpl implements WaterPump {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected WaterPumpImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WNLMLPackage.Literals.WATER_PUMP;
	}

} //WaterPumpImpl
