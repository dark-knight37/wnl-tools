/**
 */
package WNLML.impl;

import WNLML.Valve;
import WNLML.WNLMLPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Valve</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ValveImpl extends WNNodeImpl implements Valve {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ValveImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WNLMLPackage.Literals.VALVE;
	}

} //ValveImpl
