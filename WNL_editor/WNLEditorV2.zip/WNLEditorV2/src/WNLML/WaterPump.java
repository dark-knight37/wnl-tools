/**
 */
package WNLML;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Water Pump</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see WNLML.WNLMLPackage#getWaterPump()
 * @model annotation="gmf.node label='name' label.icon='false' label.placement='external' figure='figures.WaterPumpFigure'"
 * @generated
 */
public interface WaterPump extends WNNode {
} // WaterPump
