/**
 */
package WNLML;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Valve</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see WNLML.WNLMLPackage#getValve()
 * @model annotation="gmf.node label='name' label.icon='false' label.placement='external' figure='figures.ValveFigure'"
 * @generated
 */
public interface Valve extends WNNode {
} // Valve
