package figures;

import org.eclipse.draw2d.ImageFigure;
import activator.PluginActivator;

/**
 * @generated
 */
public class ReservoirFigure extends ImageFigure {

    public ReservoirFigure() {
        super(PluginActivator.imageDescriptorFromPlugin(PluginActivator.ID, "images/water.png").createImage(), 0);
    }

}