package figures;

import org.eclipse.draw2d.ImageFigure;
import activator.PluginActivator;

/**
 * @generated
 */
public class ValveFigure extends ImageFigure {

    public ValveFigure() {
        super(PluginActivator.imageDescriptorFromPlugin(PluginActivator.ID, "images/valve.jpg").createImage(), 0);
    }

}