/*
 * 
 */
package WNLML.diagram.edit.helpers;

/**
 * @generated
 */
public class ContaminantEditHelper extends WNLMLBaseEditHelper {
}
