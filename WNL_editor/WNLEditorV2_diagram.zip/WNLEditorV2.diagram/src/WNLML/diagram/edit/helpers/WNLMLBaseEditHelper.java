/*
 * 
 */
package WNLML.diagram.edit.helpers;

import org.eclipse.gmf.tooling.runtime.edit.helpers.GeneratedEditHelperBase;

/**
 * @generated
 */
public class WNLMLBaseEditHelper extends GeneratedEditHelperBase {

}
