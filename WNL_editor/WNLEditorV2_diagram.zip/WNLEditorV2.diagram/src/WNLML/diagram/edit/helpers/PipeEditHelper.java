/*
 * 
 */
package WNLML.diagram.edit.helpers;

/**
 * @generated
 */
public class PipeEditHelper extends WNLMLBaseEditHelper {
}
